﻿Public Class frmReciept

End Class