﻿Public Class frmListProducts
    Private Sub frmListProducts_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        query = "SELECT tblItems.ITEMBARCODE as Barcode, (tblItems.ITEMNAME & ' ' & tblItems.DESCRIPTION ) as Products, tblItems.OPRICE as Price, Last(tblItems.ITEMQTY)+SUM(tblsoldout.TRANSQTY) AS QTY, Sum(tblsoldout.TRANSQTY) AS SOLD, Last(tblItems.ITEMQTY) AS REMAINING
                FROM tblItems INNER JOIN tblsoldout ON tblItems.ITEMBARCODE=tblsoldout.ITEMBARCODE
                GROUP BY tblItems.ITEMBARCODE, tblItems.ITEMNAME, tblItems.DESCRIPTION, tblItems.OPRICE"
        LoadDTG(query, DTGLIST)
    End Sub

    Private Sub TXTSEARCH_TextChanged(sender As Object, e As EventArgs) Handles TXTSEARCH.TextChanged
        query = "SELECT tblItems.ITEMBARCODE as Barcode, (tblItems.ITEMNAME & ' ' & tblItems.DESCRIPTION ) as Products, tblItems.OPRICE as Price, Last(tblItems.ITEMQTY)+SUM(tblsoldout.TRANSQTY) AS QTY, Sum(tblsoldout.TRANSQTY) AS SOLD, Last(tblItems.ITEMQTY) AS REMAINING
                FROM tblItems INNER JOIN tblsoldout ON tblItems.ITEMBARCODE=tblsoldout.ITEMBARCODE WHERE (tblItems.ITEMNAME & ' ' & tblItems.DESCRIPTION ) LIKE '%" & TXTSEARCH.Text & "%'
                GROUP BY tblItems.ITEMBARCODE, tblItems.ITEMNAME, tblItems.DESCRIPTION, tblItems.OPRICE"
        LoadDTG(query, DTGLIST)
    End Sub
End Class