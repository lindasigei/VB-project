﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmPOS
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPOS))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.lblvat = New System.Windows.Forms.Label()
        Me.toolstrpUtype = New System.Windows.Forms.ToolStripButton()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.toolstrpDatetime = New System.Windows.Forms.ToolStripLabel()
        Me.toolstrpAccountId = New System.Windows.Forms.ToolStripLabel()
        Me.LBLUSERID = New System.Windows.Forms.Label()
        Me.LBLSUBTOT = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.LBLCHANGE = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.BTNESCAPE = New System.Windows.Forms.Button()
        Me.BTNTENDER = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.LBLTOTPRICE = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lbltotalsales = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel2 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.LBLSUBTOTAL = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.LBLTRANSID = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.FlowLayoutPanel4 = New System.Windows.Forms.FlowLayoutPanel()
        Me.dtgCart = New System.Windows.Forms.DataGridView()
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TXTITEMID = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.btnaddQty = New System.Windows.Forms.Button()
        Me.btnVoid = New System.Windows.Forms.Button()
        Me.BTNSAVE = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.TXTTENDERED = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel3 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Mnstrp_ShortCutMenu = New System.Windows.Forms.MenuStrip()
        Me.TToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.VoidToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TENDEREDToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ESCToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BTNADD = New System.Windows.Forms.Button()
        Me.ToolStrip1.SuspendLayout()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.FlowLayoutPanel2.SuspendLayout()
        Me.FlowLayoutPanel4.SuspendLayout()
        CType(Me.dtgCart, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.FlowLayoutPanel3.SuspendLayout()
        Me.Mnstrp_ShortCutMenu.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblvat
        '
        Me.lblvat.AutoSize = True
        Me.lblvat.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblvat.Location = New System.Drawing.Point(175, 31)
        Me.lblvat.Name = "lblvat"
        Me.lblvat.Size = New System.Drawing.Size(49, 20)
        Me.lblvat.TabIndex = 16
        Me.lblvat.Text = "12 %"
        '
        'toolstrpUtype
        '
        Me.toolstrpUtype.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.toolstrpUtype.Image = CType(resources.GetObject("toolstrpUtype.Image"), System.Drawing.Image)
        Me.toolstrpUtype.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.toolstrpUtype.Name = "toolstrpUtype"
        Me.toolstrpUtype.Size = New System.Drawing.Size(100, 22)
        Me.toolstrpUtype.Text = "ToolStripButton1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(220, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(36, 17)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "PHP"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.BackColor = System.Drawing.Color.Transparent
        Me.ToolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.toolstrpDatetime, Me.toolstrpAccountId, Me.toolstrpUtype})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 513)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(1028, 25)
        Me.ToolStrip1.TabIndex = 34
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'toolstrpDatetime
        '
        Me.toolstrpDatetime.Name = "toolstrpDatetime"
        Me.toolstrpDatetime.Size = New System.Drawing.Size(88, 22)
        Me.toolstrpDatetime.Text = "ToolStripLabel1"
        '
        'toolstrpAccountId
        '
        Me.toolstrpAccountId.AccessibleRole = System.Windows.Forms.AccessibleRole.MenuBar
        Me.toolstrpAccountId.Name = "toolstrpAccountId"
        Me.toolstrpAccountId.Size = New System.Drawing.Size(88, 22)
        Me.toolstrpAccountId.Text = "ToolStripLabel1"
        '
        'LBLUSERID
        '
        Me.LBLUSERID.AutoSize = True
        Me.LBLUSERID.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLUSERID.Location = New System.Drawing.Point(345, 300)
        Me.LBLUSERID.Name = "LBLUSERID"
        Me.LBLUSERID.Size = New System.Drawing.Size(19, 20)
        Me.LBLUSERID.TabIndex = 33
        Me.LBLUSERID.Text = "2"
        '
        'LBLSUBTOT
        '
        Me.LBLSUBTOT.AutoSize = True
        Me.LBLSUBTOT.BackColor = System.Drawing.Color.DimGray
        Me.LBLSUBTOT.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLSUBTOT.ForeColor = System.Drawing.Color.Cyan
        Me.LBLSUBTOT.Location = New System.Drawing.Point(169, 0)
        Me.LBLSUBTOT.Name = "LBLSUBTOT"
        Me.LBLSUBTOT.Size = New System.Drawing.Size(45, 29)
        Me.LBLSUBTOT.TabIndex = 7
        Me.LBLSUBTOT.Text = "0.0"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(107, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(56, 18)
        Me.Label13.TabIndex = 7
        Me.Label13.Text = "Total :"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(216, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(36, 16)
        Me.Label9.TabIndex = 9
        Me.Label9.Text = "PHP"
        '
        'LBLCHANGE
        '
        Me.LBLCHANGE.AutoSize = True
        Me.LBLCHANGE.BackColor = System.Drawing.Color.DimGray
        Me.LBLCHANGE.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLCHANGE.ForeColor = System.Drawing.Color.Cyan
        Me.LBLCHANGE.Location = New System.Drawing.Point(175, 0)
        Me.LBLCHANGE.Name = "LBLCHANGE"
        Me.LBLCHANGE.Size = New System.Drawing.Size(35, 24)
        Me.LBLCHANGE.TabIndex = 7
        Me.LBLCHANGE.Text = "0.0"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(93, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(76, 20)
        Me.Label11.TabIndex = 7
        Me.Label11.Text = "Change:"
        '
        'BTNESCAPE
        '
        Me.BTNESCAPE.Enabled = False
        Me.BTNESCAPE.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTNESCAPE.Location = New System.Drawing.Point(208, 15)
        Me.BTNESCAPE.Name = "BTNESCAPE"
        Me.BTNESCAPE.Size = New System.Drawing.Size(50, 56)
        Me.BTNESCAPE.TabIndex = 12
        Me.BTNESCAPE.Text = "ESC"
        Me.BTNESCAPE.UseVisualStyleBackColor = True
        '
        'BTNTENDER
        '
        Me.BTNTENDER.Enabled = False
        Me.BTNTENDER.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTNTENDER.Location = New System.Drawing.Point(152, 15)
        Me.BTNTENDER.Name = "BTNTENDER"
        Me.BTNTENDER.Size = New System.Drawing.Size(50, 56)
        Me.BTNTENDER.TabIndex = 12
        Me.BTNTENDER.Text = " F11"
        Me.BTNTENDER.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(57, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(132, 25)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Total Sales :"
        '
        'LBLTOTPRICE
        '
        Me.LBLTOTPRICE.AutoSize = True
        Me.LBLTOTPRICE.BackColor = System.Drawing.Color.DimGray
        Me.LBLTOTPRICE.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLTOTPRICE.ForeColor = System.Drawing.Color.Cyan
        Me.LBLTOTPRICE.Location = New System.Drawing.Point(219, 25)
        Me.LBLTOTPRICE.Name = "LBLTOTPRICE"
        Me.LBLTOTPRICE.Size = New System.Drawing.Size(65, 37)
        Me.LBLTOTPRICE.TabIndex = 7
        Me.LBLTOTPRICE.Text = "0.0"
        Me.LBLTOTPRICE.Visible = False
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.Controls.Add(Me.Label4)
        Me.FlowLayoutPanel1.Controls.Add(Me.lbltotalsales)
        Me.FlowLayoutPanel1.Controls.Add(Me.Label3)
        Me.FlowLayoutPanel1.Controls.Add(Me.LBLTOTPRICE)
        Me.FlowLayoutPanel1.FlowDirection = System.Windows.Forms.FlowDirection.RightToLeft
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(729, 23)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(287, 29)
        Me.FlowLayoutPanel1.TabIndex = 31
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(243, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(41, 20)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "PHP"
        '
        'lbltotalsales
        '
        Me.lbltotalsales.AutoSize = True
        Me.lbltotalsales.BackColor = System.Drawing.Color.DimGray
        Me.lbltotalsales.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbltotalsales.ForeColor = System.Drawing.Color.Cyan
        Me.lbltotalsales.Location = New System.Drawing.Point(195, 0)
        Me.lbltotalsales.Name = "lbltotalsales"
        Me.lbltotalsales.Size = New System.Drawing.Size(42, 25)
        Me.lbltotalsales.TabIndex = 10
        Me.lbltotalsales.Text = "0.0"
        '
        'FlowLayoutPanel2
        '
        Me.FlowLayoutPanel2.Controls.Add(Me.Label5)
        Me.FlowLayoutPanel2.Controls.Add(Me.LBLSUBTOTAL)
        Me.FlowLayoutPanel2.Controls.Add(Me.Label7)
        Me.FlowLayoutPanel2.FlowDirection = System.Windows.Forms.FlowDirection.RightToLeft
        Me.FlowLayoutPanel2.Location = New System.Drawing.Point(316, 464)
        Me.FlowLayoutPanel2.Name = "FlowLayoutPanel2"
        Me.FlowLayoutPanel2.Size = New System.Drawing.Size(407, 28)
        Me.FlowLayoutPanel2.TabIndex = 32
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(368, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(36, 17)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "PHP"
        '
        'LBLSUBTOTAL
        '
        Me.LBLSUBTOTAL.AutoSize = True
        Me.LBLSUBTOTAL.BackColor = System.Drawing.Color.DimGray
        Me.LBLSUBTOTAL.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLSUBTOTAL.ForeColor = System.Drawing.Color.Cyan
        Me.LBLSUBTOTAL.Location = New System.Drawing.Point(320, 0)
        Me.LBLSUBTOTAL.Name = "LBLSUBTOTAL"
        Me.LBLSUBTOTAL.Size = New System.Drawing.Size(42, 25)
        Me.LBLSUBTOTAL.TabIndex = 7
        Me.LBLSUBTOTAL.Text = "0.0"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(255, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(59, 20)
        Me.Label7.TabIndex = 7
        Me.Label7.Text = "Total :"
        '
        'LBLTRANSID
        '
        Me.LBLTRANSID.AutoSize = True
        Me.LBLTRANSID.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LBLTRANSID.Location = New System.Drawing.Point(885, 65)
        Me.LBLTRANSID.Name = "LBLTRANSID"
        Me.LBLTRANSID.Size = New System.Drawing.Size(85, 20)
        Me.LBLTRANSID.TabIndex = 26
        Me.LBLTRANSID.Text = "Trans Id :"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(751, 64)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(128, 20)
        Me.Label10.TabIndex = 27
        Me.Label10.Text = "Transaction # :"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(127, 31)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(42, 20)
        Me.Label17.TabIndex = 16
        Me.Label17.Text = "Vat :"
        '
        'Timer1
        '
        '
        'FlowLayoutPanel4
        '
        Me.FlowLayoutPanel4.Controls.Add(Me.Label2)
        Me.FlowLayoutPanel4.Controls.Add(Me.LBLSUBTOT)
        Me.FlowLayoutPanel4.Controls.Add(Me.Label13)
        Me.FlowLayoutPanel4.FlowDirection = System.Windows.Forms.FlowDirection.RightToLeft
        Me.FlowLayoutPanel4.Location = New System.Drawing.Point(6, 65)
        Me.FlowLayoutPanel4.Name = "FlowLayoutPanel4"
        Me.FlowLayoutPanel4.Size = New System.Drawing.Size(259, 29)
        Me.FlowLayoutPanel4.TabIndex = 12
        '
        'dtgCart
        '
        Me.dtgCart.AllowUserToAddRows = False
        Me.dtgCart.AllowUserToDeleteRows = False
        Me.dtgCart.AllowUserToResizeColumns = False
        Me.dtgCart.AllowUserToResizeRows = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dtgCart.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dtgCart.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dtgCart.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column6, Me.Column1, Me.Column2, Me.Column3, Me.Column4, Me.Column5})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dtgCart.DefaultCellStyle = DataGridViewCellStyle2
        Me.dtgCart.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically
        Me.dtgCart.Location = New System.Drawing.Point(8, 48)
        Me.dtgCart.MultiSelect = False
        Me.dtgCart.Name = "dtgCart"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dtgCart.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dtgCart.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dtgCart.Size = New System.Drawing.Size(720, 410)
        Me.dtgCart.TabIndex = 25
        '
        'Column6
        '
        Me.Column6.HeaderText = "Barcode"
        Me.Column6.Name = "Column6"
        Me.Column6.Width = 72
        '
        'Column1
        '
        Me.Column1.HeaderText = "Item Name"
        Me.Column1.Name = "Column1"
        Me.Column1.Width = 150
        '
        'Column2
        '
        Me.Column2.HeaderText = "Description"
        Me.Column2.Name = "Column2"
        Me.Column2.Width = 250
        '
        'Column3
        '
        Me.Column3.HeaderText = "Price"
        Me.Column3.Name = "Column3"
        Me.Column3.Width = 56
        '
        'Column4
        '
        Me.Column4.HeaderText = "Quantity"
        Me.Column4.Name = "Column4"
        Me.Column4.Width = 71
        '
        'Column5
        '
        Me.Column5.HeaderText = "Sub Total"
        Me.Column5.Name = "Column5"
        Me.Column5.Width = 78
        '
        'TXTITEMID
        '
        Me.TXTITEMID.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.TXTITEMID.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.TXTITEMID.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXTITEMID.Location = New System.Drawing.Point(102, 17)
        Me.TXTITEMID.Name = "TXTITEMID"
        Me.TXTITEMID.Size = New System.Drawing.Size(621, 26)
        Me.TXTITEMID.TabIndex = 24
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Controls.Add(Me.Label15)
        Me.Panel1.Controls.Add(Me.Label14)
        Me.Panel1.Controls.Add(Me.Label12)
        Me.Panel1.Controls.Add(Me.btnaddQty)
        Me.Panel1.Controls.Add(Me.btnVoid)
        Me.Panel1.Controls.Add(Me.BTNSAVE)
        Me.Panel1.Controls.Add(Me.GroupBox1)
        Me.Panel1.Controls.Add(Me.BTNESCAPE)
        Me.Panel1.Controls.Add(Me.BTNTENDER)
        Me.Panel1.Controls.Add(Me.Mnstrp_ShortCutMenu)
        Me.Panel1.Location = New System.Drawing.Point(733, 94)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(287, 377)
        Me.Panel1.TabIndex = 30
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(213, 75)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(48, 13)
        Me.Label16.TabIndex = 25
        Me.Label16.Text = "escape"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(158, 75)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(51, 26)
        Me.Label15.TabIndex = 25
        Me.Label15.Text = "Tender " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Amount"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(106, 75)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(32, 13)
        Me.Label14.TabIndex = 25
        Me.Label14.Text = "Void"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(41, 75)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(54, 13)
        Me.Label12.TabIndex = 25
        Me.Label12.Text = "Quantity"
        '
        'btnaddQty
        '
        Me.btnaddQty.Enabled = False
        Me.btnaddQty.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnaddQty.Location = New System.Drawing.Point(40, 16)
        Me.btnaddQty.Name = "btnaddQty"
        Me.btnaddQty.Size = New System.Drawing.Size(50, 56)
        Me.btnaddQty.TabIndex = 12
        Me.btnaddQty.Text = "F3"
        Me.btnaddQty.UseVisualStyleBackColor = True
        '
        'btnVoid
        '
        Me.btnVoid.Enabled = False
        Me.btnVoid.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnVoid.Location = New System.Drawing.Point(96, 16)
        Me.btnVoid.Name = "btnVoid"
        Me.btnVoid.Size = New System.Drawing.Size(50, 56)
        Me.btnVoid.TabIndex = 12
        Me.btnVoid.Text = "F10"
        Me.btnVoid.UseVisualStyleBackColor = True
        '
        'BTNSAVE
        '
        Me.BTNSAVE.Enabled = False
        Me.BTNSAVE.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTNSAVE.Location = New System.Drawing.Point(67, 319)
        Me.BTNSAVE.Name = "BTNSAVE"
        Me.BTNSAVE.Size = New System.Drawing.Size(169, 40)
        Me.BTNSAVE.TabIndex = 11
        Me.BTNSAVE.Text = "Save & Print"
        Me.BTNSAVE.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lblvat)
        Me.GroupBox1.Controls.Add(Me.Label17)
        Me.GroupBox1.Controls.Add(Me.FlowLayoutPanel4)
        Me.GroupBox1.Controls.Add(Me.TXTTENDERED)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.FlowLayoutPanel3)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(9, 99)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(271, 214)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Summary"
        '
        'TXTTENDERED
        '
        Me.TXTTENDERED.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXTTENDERED.Location = New System.Drawing.Point(90, 100)
        Me.TXTTENDERED.Multiline = True
        Me.TXTTENDERED.Name = "TXTTENDERED"
        Me.TXTTENDERED.Size = New System.Drawing.Size(175, 34)
        Me.TXTTENDERED.TabIndex = 15
        Me.TXTTENDERED.Text = "0.0"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(6, 100)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(78, 34)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "Tendered" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " Amount :"
        '
        'FlowLayoutPanel3
        '
        Me.FlowLayoutPanel3.Controls.Add(Me.Label9)
        Me.FlowLayoutPanel3.Controls.Add(Me.LBLCHANGE)
        Me.FlowLayoutPanel3.Controls.Add(Me.Label11)
        Me.FlowLayoutPanel3.FlowDirection = System.Windows.Forms.FlowDirection.RightToLeft
        Me.FlowLayoutPanel3.Location = New System.Drawing.Point(10, 173)
        Me.FlowLayoutPanel3.Name = "FlowLayoutPanel3"
        Me.FlowLayoutPanel3.Size = New System.Drawing.Size(255, 35)
        Me.FlowLayoutPanel3.TabIndex = 11
        '
        'Mnstrp_ShortCutMenu
        '
        Me.Mnstrp_ShortCutMenu.AutoSize = False
        Me.Mnstrp_ShortCutMenu.BackColor = System.Drawing.Color.Transparent
        Me.Mnstrp_ShortCutMenu.Dock = System.Windows.Forms.DockStyle.None
        Me.Mnstrp_ShortCutMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TToolStripMenuItem, Me.VoidToolStripMenuItem, Me.TENDEREDToolStripMenuItem, Me.ESCToolStripMenuItem})
        Me.Mnstrp_ShortCutMenu.Location = New System.Drawing.Point(57, 33)
        Me.Mnstrp_ShortCutMenu.Name = "Mnstrp_ShortCutMenu"
        Me.Mnstrp_ShortCutMenu.Size = New System.Drawing.Size(22, 26)
        Me.Mnstrp_ShortCutMenu.TabIndex = 24
        Me.Mnstrp_ShortCutMenu.Text = "MenuStrip1"
        '
        'TToolStripMenuItem
        '
        Me.TToolStripMenuItem.AutoSize = False
        Me.TToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.TToolStripMenuItem.Name = "TToolStripMenuItem"
        Me.TToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F3
        Me.TToolStripMenuItem.Size = New System.Drawing.Size(38, 62)
        Me.TToolStripMenuItem.Text = "Qty"
        '
        'VoidToolStripMenuItem
        '
        Me.VoidToolStripMenuItem.AutoSize = False
        Me.VoidToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.VoidToolStripMenuItem.Name = "VoidToolStripMenuItem"
        Me.VoidToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F10
        Me.VoidToolStripMenuItem.Size = New System.Drawing.Size(43, 62)
        Me.VoidToolStripMenuItem.Text = "Void"
        '
        'TENDEREDToolStripMenuItem
        '
        Me.TENDEREDToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.TENDEREDToolStripMenuItem.Name = "TENDEREDToolStripMenuItem"
        Me.TENDEREDToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F11
        Me.TENDEREDToolStripMenuItem.Size = New System.Drawing.Size(106, 22)
        Me.TENDEREDToolStripMenuItem.Text = "Tender Amount"
        '
        'ESCToolStripMenuItem
        '
        Me.ESCToolStripMenuItem.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold)
        Me.ESCToolStripMenuItem.Name = "ESCToolStripMenuItem"
        Me.ESCToolStripMenuItem.Size = New System.Drawing.Size(39, 22)
        Me.ESCToolStripMenuItem.Text = "ESC"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(19, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(77, 20)
        Me.Label1.TabIndex = 28
        Me.Label1.Text = "Barcode :"
        '
        'BTNADD
        '
        Me.BTNADD.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTNADD.Location = New System.Drawing.Point(635, 83)
        Me.BTNADD.Name = "BTNADD"
        Me.BTNADD.Size = New System.Drawing.Size(81, 26)
        Me.BTNADD.TabIndex = 29
        Me.BTNADD.Text = "Add"
        Me.BTNADD.UseVisualStyleBackColor = True
        '
        'frmPOS
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1028, 538)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.FlowLayoutPanel1)
        Me.Controls.Add(Me.FlowLayoutPanel2)
        Me.Controls.Add(Me.LBLTRANSID)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.dtgCart)
        Me.Controls.Add(Me.TXTITEMID)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.BTNADD)
        Me.Controls.Add(Me.LBLUSERID)
        Me.Name = "frmPOS"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "POS"
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.FlowLayoutPanel1.PerformLayout()
        Me.FlowLayoutPanel2.ResumeLayout(False)
        Me.FlowLayoutPanel2.PerformLayout()
        Me.FlowLayoutPanel4.ResumeLayout(False)
        Me.FlowLayoutPanel4.PerformLayout()
        CType(Me.dtgCart, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.FlowLayoutPanel3.ResumeLayout(False)
        Me.FlowLayoutPanel3.PerformLayout()
        Me.Mnstrp_ShortCutMenu.ResumeLayout(False)
        Me.Mnstrp_ShortCutMenu.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblvat As Label
    Friend WithEvents toolstrpUtype As ToolStripButton
    Friend WithEvents Label2 As Label
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents toolstrpDatetime As ToolStripLabel
    Friend WithEvents toolstrpAccountId As ToolStripLabel
    Friend WithEvents LBLUSERID As Label
    Friend WithEvents LBLSUBTOT As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents LBLCHANGE As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents BTNESCAPE As Button
    Friend WithEvents BTNTENDER As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents LBLTOTPRICE As Label
    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents Label4 As Label
    Friend WithEvents lbltotalsales As Label
    Friend WithEvents FlowLayoutPanel2 As FlowLayoutPanel
    Friend WithEvents Label5 As Label
    Friend WithEvents LBLSUBTOTAL As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents LBLTRANSID As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents FlowLayoutPanel4 As FlowLayoutPanel
    Friend WithEvents dtgCart As DataGridView
    Friend WithEvents TXTITEMID As TextBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label16 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents btnaddQty As Button
    Friend WithEvents btnVoid As Button
    Friend WithEvents Mnstrp_ShortCutMenu As MenuStrip
    Friend WithEvents VoidToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents TENDEREDToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ESCToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BTNSAVE As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents TXTTENDERED As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents FlowLayoutPanel3 As FlowLayoutPanel
    Friend WithEvents Label1 As Label
    Friend WithEvents BTNADD As Button
    Friend WithEvents Column6 As DataGridViewTextBoxColumn
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
End Class
