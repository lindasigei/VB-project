﻿Public Class Form1
    Private Sub RegisterNewItemsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RegisterNewItemsToolStripMenuItem.Click
        frmProducts.ShowDialog()
        clear(frmProducts)

    End Sub

    Private Sub disabled_menu()
        ManageProductsToolStripMenuItem.Enabled = False
        ManageUsersToolStripMenuItem.Enabled = False
        ReportsToolStripMenuItem.Enabled = False
        tsPOS.Enabled = False
        tsSearchProducts.Enabled = False
        LoginToolStripMenuItem.Text = "Login"
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        disabled_menu()
    End Sub

    Private Sub StockInToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StockInToolStripMenuItem.Click
        frmStockin.ShowDialog()
    End Sub

    Private Sub ManageUsersToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ManageUsersToolStripMenuItem.Click
        frmManageUsers.ShowDialog()

    End Sub

    Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs) Handles tsPOS.Click
        frmPOS.ShowDialog()
    End Sub

    Private Sub InventoryReportToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles InventoryReportToolStripMenuItem.Click
        query = "SELECT tblItems.ITEMBARCODE, tblItems.ITEMNAME, tblItems.DESCRIPTION, tblItems.OPRICE, Last(tblItems.ITEMQTY) + SUM(tblsoldout.TRANSQTY) AS QTY, Sum(tblsoldout.TRANSQTY) AS SOLD, Last(tblItems.ITEMQTY) AS REMAINING" &
            " FROM tblItems INNER JOIN tblsoldout ON tblItems.ITEMBARCODE = tblsoldout.ITEMBARCODE " &
            " GROUP BY tblItems.ITEMBARCODE, tblItems.ITEMNAME, tblItems.DESCRIPTION, tblItems.OPRICE"
        reports(query, "inventory", frmReport.CrystalReportViewer1)
        frmReport.ShowDialog()
    End Sub

    Private Sub SalesReportToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SalesReportToolStripMenuItem.Click
        query = "SELECT tblItems.ITEMBARCODE , [ITEMNAME] & ' ' & [DESCRIPTION] AS Products, Sum(tblsoldout.TRANSQTY) AS QTY, Sum(tblsoldout.SUBTOTAL) AS TotalAmount
FROM tblItems INNER JOIN tblsoldout ON tblItems.ITEMBARCODE = tblsoldout.ITEMBARCODE WHERE FORMAT(TRANSDATE,'mm/dd/yyyy') = FORMAT(Now(),'mm/dd/yyyy') 
GROUP BY tblItems.ITEMBARCODE, [ITEMNAME] & ' ' & [DESCRIPTION]"
        reports(query, "sales", frmReport.CrystalReportViewer1)
        frmReport.ShowDialog()
    End Sub

    Private Sub ToolStripButton2_Click(sender As Object, e As EventArgs) Handles tsSearchProducts.Click
        frmListProducts.ShowDialog()
    End Sub

    Private Sub LoginToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LoginToolStripMenuItem.Click
        If LoginToolStripMenuItem.Text = "Login" Then
            frmLogin.ShowDialog()
        Else
            disabled_menu()
        End If
    End Sub
End Class
